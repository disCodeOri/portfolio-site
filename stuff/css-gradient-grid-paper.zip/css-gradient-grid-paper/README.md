# CSS Gradient Grid Paper

A Pen created on CodePen.

Original URL: [https://codepen.io/simeydotme/pen/PwzGVRL](https://codepen.io/simeydotme/pen/PwzGVRL).

Using CSS Gradients (linear/radial) to make a grid-paper background with variable size/styling